Parametric Bottle Cap / Jar Lid by degroof on Thingiverse: https://www.thingiverse.com/thing:5397832

Summary:
A generic lid/cap for bottles and jars. Can be configured to fit most containers. Allows for containers with multiple interleaved threads.
