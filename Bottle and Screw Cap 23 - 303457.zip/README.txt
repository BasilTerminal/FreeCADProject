Bottle and Screw Cap 23 by David_Mussaffi on Thingiverse: https://www.thingiverse.com/thing:303457

Summary:
Bottle and Screw Cap 23https://www.youtube.com/watch?v=eynH8q_84-0
