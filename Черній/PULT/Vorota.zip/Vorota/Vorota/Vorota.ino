#include <RCSwitch.h>

#define vorota_open 12937716
#define vorota_close 12937720

RCSwitch mySwitch = RCSwitch();

void setup() {
  Serial.begin(9600);
  pinMode(3, OUTPUT);
  pinMode(4, OUTPUT);
  pinMode(5, INPUT_PULLUP);
  pinMode(6, INPUT_PULLUP);
  digitalWrite(3, 0);
  digitalWrite(4, 0);
  mySwitch.enableReceive(0);  // Receiver on interrupt 0 => that is pin #2
}
bool btn_state = false;
unsigned long reset_state_tmr = 0;
bool open = 0;
bool close = 0;

void loop() {
  bool koncev1 = digitalRead(5);
  bool koncev2 = digitalRead(6);
  Serial.print(koncev1);
  Serial.print(" ");
  Serial.println(koncev2);
  if (koncev1 == LOW) {
    digitalWrite(3, 0);
    open = false;
  }
  if (koncev2 == LOW) {
    digitalWrite(4, 0);
    close = false;
  }

  if (((millis() / 1000) * 1000) - reset_state_tmr >= 2) {
    btn_state = false;
  }
  if (mySwitch.available()) {
    if (mySwitch.getReceivedValue() == vorota_open && btn_state == false) {
      btn_state = true;
      if (open) open = false;
      else open = true;
      if (close) open = false;
      close = false;
      if (koncev1 == LOW) open = false;
      reset_state_tmr = ((millis() / 1000) * 1000);
      Serial.println("OPEN");
    }
    if (mySwitch.getReceivedValue() == vorota_close && btn_state == false) {
      btn_state = true;
      if (close) close = false;
      else close = true;
      if (open) close = false;
      open = false;
      if (koncev2 == LOW) close = false;
      reset_state_tmr = ((millis() / 1000) * 1000);
      Serial.println("CLOSE");
    }
    if (open) {
      digitalWrite(3, 1);
      digitalWrite(4, 0);
    } else digitalWrite(3, 0);
    if (close) {
      digitalWrite(3, 0);
      digitalWrite(4, 1);
    } else digitalWrite(4, 0);
  }
  mySwitch.resetAvailable();
}
